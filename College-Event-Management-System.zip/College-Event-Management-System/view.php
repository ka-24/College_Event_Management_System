<?php   
 include "database/connect.php"; 
 if (isset($_GET['id'])) {  
     $UserFullName = $_GET['id'];  
     $query="SELECT e.EventName from booking_details b,event_details e where e.EventID = b.EventID ";
     $run = mysqli_query($conn,$query);  
      if ($run) {  
           header('location:admin_view.php');  
      }else{  
           echo "Error: ".mysqli_error($conn);  
      }  
 }  
 ?>